Đặt video (.mp4), ảnh poster (.jpg), ảnh chân dung và logo khách hàng vào đây.
